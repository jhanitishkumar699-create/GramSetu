const API=import.meta.env.VITE_API_URL||'http://localhost:4000';
export async function api<T>(path:string,init:RequestInit={}):Promise<T>{const r=await fetch(`${API}${path}`,{...init,headers:{'Content-Type':'application/json',...(init.headers||{})}});if(!r.ok)throw new Error((await r.json().catch(()=>({error:r.statusText}))).error||'API request failed');return r.status===204?undefined as T:r.json();}
export const getProducts=()=>api<{data:unknown[]}>('/api/products');
export const estimateShipping=(weightKg:number,distanceKm:number,delivery:'Standard'|'Express')=>api<{kind:string;amount:number;etaDays:number;notice:string}>('/api/shipping/estimate',{method:'POST',body:JSON.stringify({weightKg,distanceKm,delivery})});
