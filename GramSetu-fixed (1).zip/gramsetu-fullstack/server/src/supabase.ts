import { createClient } from '@supabase/supabase-js';
const url=process.env.SUPABASE_URL!;
const anon=process.env.SUPABASE_ANON_KEY!;
if(!url||!anon) throw new Error('Set SUPABASE_URL and SUPABASE_ANON_KEY in server/.env');
export const supabase=createClient(url,anon,{auth:{persistSession:false,autoRefreshToken:false}});
