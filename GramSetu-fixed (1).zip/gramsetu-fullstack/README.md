# GramSetu Full-stack starter
React/Vite frontend plus Express API and Supabase PostgreSQL schema. Demo UI remains available; API scaffold includes public approved-product listing, authenticated producer CRUD, validation, and clearly simulated shipping estimates. Checkout/order transaction endpoints are not yet wired into the existing UI; see limitations below.

## Setup
1. Create a Supabase project. In SQL Editor run `server/supabase/schema.sql`.
2. Copy `server/.env.example` to `server/.env`; set project URL and anon key. Never put service-role key in frontend.
3. From `server/`: `npm install`, `npm run dev` (API on port 4000).
4. In project root: `npm install`; copy `.env.example` to `.env`; `npm run dev` (Vite on 5173).
5. API health: `http://localhost:4000/api/health`.

## Auth
Use Supabase Auth sign-up/sign-in in the client and send its access token as `Authorization: Bearer <token>` to protected API routes. Create matching `profiles` rows with role after signup; role assignment/admin provisioning must be server-controlled in a deployed system. Current UI role switch is a visual demo selector, not authorization.

## Important status
This is an integration-ready project scaffold, not a fully audited production commerce system. The current UI's cart and checkout remain local demo state and do not create persisted orders. Before real use, implement atomic checkout via a Postgres RPC/transaction (lock product rows, validate stock, decrement stock, insert order/items), strict role checks/admin policies, storage bucket policies, rate limiting, tests, and actual carrier/payment integrations. Shipping estimates are demo-only.
